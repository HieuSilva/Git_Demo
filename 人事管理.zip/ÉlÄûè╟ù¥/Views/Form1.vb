﻿Imports System.ComponentModel

Public Class Form1

    Private CurrentPage As Integer = 1
    Private TotalPage As Integer = 0
    Private EmpCtr As EmployeeController
    Private EmployeeList As List(Of Employee)
    Private SelectedEmployee As Employee = Nothing

    Public Sub New()
        InitializeComponent()
        InitComponents()
    End Sub

    Private Sub InitComponents()
        ClearInputs()
        cbbPageSize.SelectedItem = "5"
        lbPage.Text = CurrentPage.ToString()
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

    End Sub

    Private Sub DisplayEmployeeList(ByVal Page As Integer, PageSize As Integer)
        Dim PaginationResult = empCtr.GetEmployeeList(Page, PageSize)
        If PaginationResult.Results.Count = 0 Then
            Return
        End If

        'Dim BindingList As BindingList(Of Employee) = New BindingList(Of Employee)(PaginationResult.Results)
        'Dim BindingSource As BindingSource = New BindingSource(BindingList, Nothing)
        'gvEmployeeList.DataSource = BindingSource

        gvEmployeeList.Rows.Clear()
        ClearInputs()

        EmployeeList = PaginationResult.Results
        For Each e As Employee In EmployeeList
            Dim row As String() = {e.Id.ToString(), e.FullName, e.Phone, e.Email, e.Group}
            gvEmployeeList.Rows.Add(row)
        Next

        CurrentPage = PaginationResult.Page
        TotalPage = PaginationResult.TotalPage
        lbPage.Text = CurrentPage.ToString()

        If (CurrentPage = 1) Then
            btnPrevious.Enabled = False
        Else
            btnPrevious.Enabled = True
        End If
        If (CurrentPage = TotalPage) Then
            btnNext.Enabled = False
        Else
            btnNext.Enabled = True
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        empCtr = New EmployeeController()
        DisplayEmployeeList(1, 5)
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
        DisplayEmployeeList(CurrentPage - 1, PageSize)
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
        DisplayEmployeeList(CurrentPage + 1, PageSize)
    End Sub

    Private Sub cbbPageSize_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbbPageSize.SelectedIndexChanged
        If (Not empCtr Is Nothing) Then
            Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
            DisplayEmployeeList(1, PageSize)
        End If
    End Sub

    Private Sub gvEmployeeList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gvEmployeeList.CellClick
        Dim i = e.RowIndex
        SelectedEmployee = EmployeeList.Item(i)
        tbName.Text = SelectedEmployee.FullName
        tbPhone.Text = SelectedEmployee.Phone
        tbMail.Text = SelectedEmployee.Email
        cbbGroup.SelectedItem = SelectedEmployee.Group
        btnUpdate.Enabled = True
        btnDelete.Enabled = True
    End Sub

    Private Sub ClearInputs()
        tbName.Text = ""
        tbPhone.Text = ""
        tbMail.Text = ""
        cbbGroup.SelectedItem = "1"
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim Employee = New Employee()
        With Employee
            .FullName = tbName.Text
            .Phone = tbPhone.Text
            .Email = tbMail.Text
            .Group = cbbGroup.SelectedItem
        End With
        EmpCtr.AddEmployee(Employee)
        Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
        DisplayEmployeeList(1, PageSize)
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim UpdatedEmployee = New Employee()
        With UpdatedEmployee
            .Id = SelectedEmployee.Id
            .FullName = tbName.Text
            .Phone = tbPhone.Text
            .Email = tbMail.Text
            .Group = cbbGroup.SelectedItem.ToString()
        End With
        EmpCtr.UpdateEmployee(UpdatedEmployee)
        Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
        DisplayEmployeeList(CurrentPage, PageSize)
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If (Not SelectedEmployee Is Nothing) Then
            EmpCtr.DeleteEmployee(SelectedEmployee.Id)
            Dim PageSize = Convert.ToUInt32(cbbPageSize.SelectedItem)
            DisplayEmployeeList(CurrentPage, PageSize)
        End If
    End Sub
End Class
