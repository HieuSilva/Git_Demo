﻿Public Class MainApp
    Public Sub Main()
        Dim StartForm As Form1 = New Form1()
        StartForm.Visible = True
    End Sub
End Class
