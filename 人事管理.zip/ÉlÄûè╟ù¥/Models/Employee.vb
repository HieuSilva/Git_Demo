﻿Public Class Employee

    Public Id As Integer
    Public FullName As String
    Public Phone As String
    Public Email As String
    Public Group As String

    Public Sub New()

    End Sub

    Public Sub New(Id As Integer, FullName As String, Phone As String, Email As String, Group As String)
        Me.Id = Id
        Me.FullName = FullName
        Me.Phone = Phone
        Me.Email = Email
        Me.Group = Group
    End Sub



End Class
