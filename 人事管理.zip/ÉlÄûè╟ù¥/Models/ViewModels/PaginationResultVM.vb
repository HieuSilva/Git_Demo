﻿Public Class PaginationResultVM
    Public Results As IList
    Public TotalRecord As Integer
    Public Page As Integer
    Public PageSize As Integer
    Public TotalPage As Integer
End Class
