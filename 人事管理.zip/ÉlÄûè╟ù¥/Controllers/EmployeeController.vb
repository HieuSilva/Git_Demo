﻿
Public Class EmployeeController

    Private EmployeeList As List(Of Employee) = New List(Of Employee)()

    Public Sub New()
        EmployeeList.Add(New Employee(1, "David Silva", "0123456789", "abc@gmail.com", "1"))
        EmployeeList.Add(New Employee(2, "Wayne Rooney", "0123456789", "abc@gmail.com", "2"))
        EmployeeList.Add(New Employee(3, "David Beckham", "0123456789", "abc@gmail.com", "3"))
        EmployeeList.Add(New Employee(4, "Kun Aguero", "0123456789", "abc@gmail.com", "2"))
        EmployeeList.Add(New Employee(5, "Carloz Tevez", "0123456789", "abc@gmail.com", "1"))
        EmployeeList.Add(New Employee(6, "Bernardo Silva", "0123456789", "abc@gmail.com", "3"))
        EmployeeList.Add(New Employee(7, "Ederson Moraes", "0123456789", "abc@gmail.com", "3"))
        EmployeeList.Add(New Employee(8, "Kyle Walker", "0123456789", "abc@gmail.com", "2"))
        EmployeeList.Add(New Employee(9, "Ilkay Gundogan", "0123456789", "abc@gmail.com", "2"))
        EmployeeList.Add(New Employee(10, "Benjamin Mendy", "0123456789", "abc@gmail.com", "1"))
    End Sub

    Public Sub AddEmployee(Employee As Employee)
        Dim MaxId = EmployeeList.OrderByDescending(Function(e) e.Id).First.Id
        Employee.Id = MaxId + 1
        EmployeeList.Add(Employee)
    End Sub

    Public Sub UpdateEmployee(Employee As Employee)
        Dim ExistingEmployee = EmployeeList.SingleOrDefault(Function(e) e.Id = Employee.Id)
        If (Not ExistingEmployee Is Nothing) Then
            With ExistingEmployee
                .FullName = Employee.FullName
                .Phone = Employee.Phone
                .Email = Employee.Email
                .Group = Employee.Group
            End With
        End If

    End Sub

    Public Sub DeleteEmployee(EmployeeId As Integer)
        Dim ExistingEmployee = EmployeeList.SingleOrDefault(Function(e) e.Id = EmployeeId)
        If (Not ExistingEmployee Is Nothing) Then
            EmployeeList.Remove(ExistingEmployee)
        End If
    End Sub


    Public Function SearchEmployee(Key As String) As List(Of Employee)
        Dim results As List(Of Employee) = EmployeeList.Where(Function(e) e.FullName.Contains(Key)).ToList()
        Return results
    End Function

    Public Function GetEmployeeList(Page As Integer, PageSize As Integer) As PaginationResultVM
        Dim emps As List(Of Employee) = EmployeeList.Skip(PageSize * (Page - 1)).Take(PageSize).ToList()
        Dim paginationResult = New PaginationResultVM()
        With paginationResult
            .Page = Page
            .PageSize = PageSize
            .TotalRecord = EmployeeList.Count
            .TotalPage = Math.Ceiling(EmployeeList.Count / PageSize)
            .Results = emps
        End With
        Return paginationResult
    End Function

End Class
